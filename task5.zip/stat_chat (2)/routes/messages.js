// routes/messages.js
const express = require('express');
const router = express.Router();
const Message = require('../models/Message');

// Create a new message
router.post('/', async (req, res) => {
    const { sender, content } = req.body;
    try {
        const message = new Message({ sender, content });
        await message.save();
        res.status(201).json(message);
    } catch (error) {
        res.status(500).json({ message: 'Error creating message', error });
    }
});

// Read all messages
router.get('/', async (req, res) => {
    try {
        const messages = await Message.find();
        res.status(200).json(messages);
    } catch (error) {
        res.status(500).json({ message: 'Error retrieving messages', error });
    }
});

// Update a message by ID
router.put('/:id', async (req, res) => {
    const { id } = req.params;
    const { content } = req.body;
    try {
        const message = await Message.findByIdAndUpdate(id, { content }, { new: true });
        res.status(200).json(message);
    } catch (error) {
        res.status(500).json({ message: 'Error updating message', error });
    }
});

// Delete a message by ID
router.delete('/:id', async (req, res) => {
    const { id } = req.params;
    try {
        await Message.findByIdAndDelete(id);
        res.status(200).json({ message: 'Message deleted' });
    } catch (error) {
        res.status(500).json({ message: 'Error deleting message', error });
    }
});
// Define Message Schema
const messageSchema = new mongoose.Schema({
    sender: String,
    receiver: String,
    content: String,
    timestamp: { type: Date, default: Date.now }
  });
  
  const Message = mongoose.model('Message', messageSchema);
  
module.exports = router;
