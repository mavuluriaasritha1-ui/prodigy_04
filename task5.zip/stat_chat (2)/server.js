const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const session = require('express-session');
const path = require('path');

const app = express();

app.use(session({
    secret: 'secret_key',  // Replace with a secure key
    resave: false,
    saveUninitialized: true,
}));

app.use(express.json());

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/chatapp', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

// Define User Schema
const userSchema = new mongoose.Schema({
    name: String,
    email: { type: String, unique: true },
    phone: String,
    password: String,
    interests: { type: [String], }
});
const User = mongoose.model('User', userSchema);



// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.set('view engine', 'ejs');
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
    secret: 'secret_key',  // Replace with a secure key
    resave: false,
    saveUninitialized: true,
}));

// Render Registration Page
app.get('/', (req, res) => {
    res.render('registration');
});

// Registration Route
// Registration Route
app.post('/register', async (req, res) => {
    const { name, email, phone, password } = req.body;
    try {
        const newUser = new User({ name, email, phone, password });
        await newUser.save();
        req.session.userId = newUser._id; // Store user ID in session
        res.redirect('/interest');  // Redirect to interest page
    } catch (error) {
        console.error(error);
        res.status(500).send('Error registering user');
    }
});


// Serve interest.ejs when /interest is requested
app.get('/interest', (req, res) => {
    res.render('interest');  // Render interest.ejs
});


app.post('/login', async (req, res) => {
    const { email, password } = req.body;
    try {
        const user = await User.findOne({ email });
        if (user && user.password === password) {
            req.session.userId = user._id;  // Store user ID in session
            req.session.userName = user.name;  // Store user name in session
            return res.redirect('/chat');  // Redirect to chat
        } else {
            res.render('registration', { error: 'Invalid email or password' });
        }
    } catch (error) {
        res.status(500).send('Server Error');
    }
});


// Serve chat.ejs when /chat is requested
app.get('/chat', async (req, res) => {
    if (!req.session.userId) {
        return res.redirect('/');  // Redirect to login if not authenticated
    }

    try {
        const currentUser = await User.findById(req.session.userId);
        const userInterests = currentUser.interests;

        // Find users with at least 2 interests in common
        const matchingUsers = await User.aggregate([
            {
                $match: {
                    _id: { $ne: currentUser._id }, // Exclude the logged-in user
                    interests: { $in: userInterests }
                }
            },
            {
                $project: {
                    name: 1,
                    commonInterests: {
                        $size: { $setIntersection: [userInterests, "$interests"] }
                    }
                }
            },
            {
                $match: {
                    commonInterests: { $gte: 2 } // Only include users with 2 or more common interests
                }
            }
        ]);

        res.render('chat', { userId: req.session.userId, userName: req.session.userName, contacts: matchingUsers });
    } catch (error) {
        console.error('Error loading chat:', error);
        res.status(500).send('Error loading chat');
    }
});


app.get('/login', async (req, res) => {
    res.redirect('/');  // Redirect to login if not authenticated
});

// CRUD Operations for Messages
// Create a new message
// Read all messages between two users
app.get('/api/messages', async (req, res) => {
    const { sender, receiver } = req.query;
    try {
        const messages = await Message.find({
            $or: [
                { sender, receiver },
                { sender: receiver, receiver: sender }
            ]
        }).sort('timestamp');
        res.status(200).send(messages);
    } catch (error) {
        res.status(500).send('Error retrieving messages');
    }
});

// Send a message from the logged-in user to the selected contact
// Define Message Schema

const messageSchema = new mongoose.Schema({
    sender: String,
    receiver: String,
    content: String,
    timestamp: { type: Date, default: Date.now }
});
const Message = mongoose.model('Message', messageSchema);

// Route to send a message
app.post('/api/messages', async (req, res) => {
    // Log the incoming request body
    console.log("Received message:", req.body);

    const { sender, receiver, content } = req.body;

    try {
        const newMessage = new Message({
            sender,
            receiver,
            content
        });

        await newMessage.save(); // Save the message to the database
        res.status(201).json(newMessage); // Send back the saved message as a response
    } catch (error) {
        console.error("Error saving message:", error);
        res.status(500).json({ error: 'Failed to send message' });
    }
});




// Define Interest Schema
const interestSchema = new mongoose.Schema({
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    interests: { type: [String], default: [] }
});
const Interest = mongoose.model('Interest', interestSchema);


// app.post('/api/interests', async (req, res) => {
//     let interests = req.body.interests; // interests should be an array
//     const userId = req.session.userId; // Get the user ID from the session

//     console.log('Interests submitted:', interests); // Debugging line
//     console.log('User ID:', userId); // Debugging line to check if userId is available

//     try {
//         // Check if interests is undefined or null
//         if (!interests) {
//             interests = []; // Set to an empty array if no interests were selected
//         } else if (!Array.isArray(interests)) {
//             interests = [interests]; // Convert to an array if a single checkbox was checked
//         }

//         // Ensure the user ID is valid
//         if (!userId) {
//             return res.status(400).send('User ID is not valid.');
//         }

//         // Upsert (update or insert) interests in the Interests collection
//         await Interest.findOneAndUpdate(
//             { userId }, // Find the interests for this user
//             { userId, interests }, // Update interests and ensure userId is included
//             { upsert: true, new: true } // Create new if not found
//         );

//         res.redirect('/chat'); // Redirect to chat after saving interests
//     } catch (error) {
//         console.error('Error saving interests:', error); // More detailed error logging
//         res.status(500).send('Error saving interests');
//     }
// });





// Start Server

app.post('/api/interests', async (req, res) => {
    let interests = req.body.interests; // interests should be an array
    const userId = req.session.userId; // Get the user ID from the session

    console.log('Interests submitted:', interests); // Debugging line

    try {
        // Check if interests is undefined or null
        if (!interests) {
            interests = []; // Set to an empty array if no interests were selected
        } else if (!Array.isArray(interests)) {
            interests = [interests]; // Convert to an array if a single checkbox was checked
        }

        // Update the user's interests
        await User.findByIdAndUpdate(userId, { interests }, { new: true });
        res.redirect('/login'); // Redirect to chat after saving interests
    } catch (error) {
        console.error('Error saving interests:', error); // More detailed error logging
        res.status(500).send('Error saving interests');
    }
});

app.get('/edit-profile', async (req, res) => {
    // Get userId from session, not from req.user
    const userId = req.session.userId; // Use session to get user ID

    if (!userId) {
        return res.status(403).send('Not authenticated'); // Return a 403 error if not authenticated
    }

    try {
        const user = await User.findById(userId); // Find user by ID
        if (!user) {
            return res.status(404).send('User not found');
        }
        res.render('edit-profile', { user }); // Render edit-profile.ejs and pass user data
    } catch (error) {
        console.error("Error fetching user:", error);
        res.status(500).send('Error retrieving user data');
    }
});



app.post('/api/users/:id', async (req, res) => {
    const userId = req.params.id;
    const { name, email, phone, password, interests } = req.body;

    try {
        const updatedUser = await User.findByIdAndUpdate(
            userId,
            {
                name,
                email,
                phone,
                password, // Ensure you handle password hashing if applicable
                interests: interests.split(',').map(interest => interest.trim()) // Convert comma-separated interests to array
            },
            { new: true } // Return the updated document
        );

        // Simply redirect to the chat page
        res.redirect('/chat');
    } catch (error) {
        console.error("Error updating user:", error);
        res.status(500).json({ error: 'Failed to update profile' });
    }
});




// Assuming you have express-session set up
app.get('/logout', (req, res) => {
    req.session.destroy(err => {
        if (err) {
            console.error("Error destroying session:", err);
            return res.status(500).send('Failed to log out');
        }
        res.redirect('/login'); // Redirect to the login page after logout
    });
});

app.post('/delete-account', async (req, res) => {
    const userId = req.session.userId; // Get userId from session

    if (!userId) {
        return res.status(403).send('Not authenticated'); // Return a 403 error if not authenticated
    }

    try {
        // Delete the user from the database
        await User.findByIdAndDelete(userId);

        // Optionally destroy the session if you want to log out the user after deletion
        req.session.destroy(err => {
            if (err) {
                console.error("Error destroying session:", err);
            }
        });

        // Redirect to login page after deletion
        res.redirect('/login');
    } catch (error) {
        console.error("Error deleting user account:", error);
        res.status(500).send('Failed to delete account');
    }
});


app.listen(3001, () => {
    console.log('Server is running on http://localhost:3001');
});
